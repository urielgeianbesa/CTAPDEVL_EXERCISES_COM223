package com.example.exercise_2

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.exercise_2.R

class Profilepage : AppCompatActivity() {

    private lateinit var profilePicImageView: ImageView
    private lateinit var editProfileButton: Button
    private lateinit var shareProfileButton: Button
    private lateinit var nameProfilePageTextView: TextView // Add TextView for username
    private val PICK_IMAGE_REQUEST = 123
    private var selectedImageUri: Uri? = null // Store the selected image URI
    private var username: String? = null // Store the username

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profilepage)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        profilePicImageView = findViewById(R.id.profilepic)
        editProfileButton = findViewById(R.id.Editprofile)
        shareProfileButton = findViewById(R.id.Shareprofile)
        nameProfilePageTextView = findViewById(R.id.nameprofilepage) // Initialize TextView

        // Get the username from the Intent
        username = intent.getStringExtra("USER_NAME")

        // Display the username
        nameProfilePageTextView.text = username ?: "User"

        // Set click listener for the "Edit profile" button
        editProfileButton.setOnClickListener {
            openImagePicker()
        }

        // Set click listener for the "Share profile" button
        shareProfileButton.setOnClickListener {
            shareProfile()
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        try {
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        } catch (e: Exception) {
            Log.e("ProfilePage", "Error starting image picker: ${e.message}")
            Toast.makeText(this, "Could not open image picker", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            if (data != null && data.data != null) {
                selectedImageUri = data.data // Store the selected image URI
                profilePicImageView.setImageURI(selectedImageUri)
            } else {
                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun shareProfile() {
        if (selectedImageUri != null) {
            val intent = Intent(this, Homepage::class.java)
            intent.putExtra("profile_image_uri", selectedImageUri.toString())
            intent.putExtra("USER_NAME", username) // Pass the username back to Homepage
            startActivity(intent)
        } else {
            Toast.makeText(this, "Please select an image first", Toast.LENGTH_SHORT).show()
        }
    }
}