package com.example.exercise_2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Hardcoded login credentials
    private val validUsername = "Kris Cubillo"
    private val validPassword = "a"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameEditText = findViewById<EditText>(R.id.username)
        val passwordEditText = findViewById<EditText>(R.id.password)
        val loginButton = findViewById<Button>(R.id.login_button)

        loginButton.setOnClickListener {
            val inputUsername = usernameEditText.text.toString().trim()
            val inputPassword = passwordEditText.text.toString().trim()

            if (inputUsername == validUsername && inputPassword == validPassword) {
                // Login success, pass the username to the Homepage
                val intentToHomepage = Intent(this, Homepage::class.java)
                intentToHomepage.putExtra("USER_NAME", inputUsername)  // Send username to Homepage
                startActivity(intentToHomepage)
            } else {
                // Login failed
                Toast.makeText(this, "The password is wrong, please try again", Toast.LENGTH_SHORT).show()
            }
        }
    }
}