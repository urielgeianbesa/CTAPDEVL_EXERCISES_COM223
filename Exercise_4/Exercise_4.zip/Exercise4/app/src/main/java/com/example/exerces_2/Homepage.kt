package com.example.exercise_2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.exercise_2.R

class Homepage : AppCompatActivity() {
    private var username: String? = null // Store the username

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        // Get the username from the Intent
        username = intent.getStringExtra("USER_NAME")

        // Display the username in the TextView with id 'User_name'
        val userNameTextView: TextView = findViewById(R.id.User_name)
        userNameTextView.text = username ?: "Guest"  // Display "Guest" if no username is provided

        // Get a reference to the ImageView (porfile1) and set its click listener
        val profile1ImageView: ImageView = findViewById(R.id.porfile1)
        profile1ImageView.setOnClickListener {
            val intentToProfile = Intent(this, Profilepage::class.java)
            intentToProfile.putExtra("USER_NAME", username) // Send username to Profilepage
            startActivity(intentToProfile)
        }
        // Optional: Add visual feedback if you haven't in XML
        // profileImageView.setBackgroundResource(android.R.attr.selectableItemBackgroundBorderless) // Consider setting in XML
        profile1ImageView.isClickable = true
        profile1ImageView.isFocusable = true

        // Get a reference to the ImageView (profile2) and set its click listener
        val profileImageView2: ImageView = findViewById(R.id.profile2)
        profileImageView2.setOnClickListener {
            val intentToProfile = Intent(this, Profilepage::class.java)
            intentToProfile.putExtra("USER_NAME", username) // Send username to Profilepage
            startActivity(intentToProfile)
        }
        // Optional: Add visual feedback if you haven't in XML
        // profileImageView2.setBackgroundResource(android.R.attr.selectableItemBackgroundBorderless) // Consider setting in XML
        profileImageView2.isClickable = true
        profileImageView2.isFocusable = true

        // Get the image URI from the Intent and display it
        val imageUriString = intent.getStringExtra("profile_image_uri")
        if (imageUriString != null) {
            val imageUri = Uri.parse(imageUriString)
            profile1ImageView.setImageURI(imageUri)
            val imageView8: ImageView = findViewById(R.id.imageView8) // Assuming you have an ImageView with id 'imageView8' in your layout
            imageView8.setImageURI(imageUri)
        }
    }
}