package com.example.exerces_2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.exercise_2.R

class FeedPostAdapter(
    private val context: Context,
    private val postList: MutableList<FeedPostItem>
) : RecyclerView.Adapter<FeedPostAdapter.FeedPostViewHolder>() {

    inner class FeedPostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Views from list_item_feed_post.xml
        val userProfileImage: ImageView = itemView.findViewById(R.id.item_user_profile_image)
        val userNameText: TextView = itemView.findViewById(R.id.item_user_name)
        val postImage: ImageView = itemView.findViewById(R.id.item_post_image)
        val heartIcon: ImageView = itemView.findViewById(R.id.item_heart_icon)
        val commentIcon: ImageView = itemView.findViewById(R.id.item_comment_icon)
        val shareIcon: ImageView = itemView.findViewById(R.id.item_share_icon)
        val saveIcon: ImageView = itemView.findViewById(R.id.item_save_icon)
        val likeCountText: TextView = itemView.findViewById(R.id.item_like_count_text)
        val descriptionText: TextView = itemView.findViewById(R.id.item_description_text)
        val viewCountText: TextView = itemView.findViewById(R.id.item_view_count_text) // This was view all comments
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeedPostViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.list_item_feed_post, parent, false)
        return FeedPostViewHolder(view)
    }

    override fun onBindViewHolder(holder: FeedPostViewHolder, position: Int) {
        val currentItem = postList[position]

        // Bind User Info
        holder.userNameText.text = currentItem.userName
        Glide.with(context)
            .load(currentItem.userProfileImageUrl ?: R.drawable.usericon) // Load profile pic or default
            .circleCrop() // Optional: if you want circular profile pics
            .placeholder(R.drawable.usericon)
            .error(R.drawable.usericon)
            .into(holder.userProfileImage)

        // Bind Post Image
        Glide.with(context)
            .load(currentItem.postImageUrl)
            .placeholder(R.drawable.media)
            .error(R.drawable.media) // An error placeholder for the main image
            .into(holder.postImage)

        // Bind Text Fields
        holder.likeCountText.text = "${currentItem.likeCount} likes" // Updated text
        holder.descriptionText.text = currentItem.descriptionText
        holder.viewCountText.text = "View all ${currentItem.commentCount} comments" // Updated to show comment count

        // Set Initial States for Icons
        updateLikeButton(holder.heartIcon, currentItem.isLiked)
        updateSaveButton(holder.saveIcon, currentItem.isSaved)

        // --- Click Listeners ---
        holder.heartIcon.setOnClickListener {
            currentItem.isLiked = !currentItem.isLiked
            if (currentItem.isLiked) currentItem.likeCount++ else currentItem.likeCount--
            if (currentItem.likeCount < 0) currentItem.likeCount = 0 // Ensure likes don't go negative
            updateLikeButton(holder.heartIcon, currentItem.isLiked)
            holder.likeCountText.text = "${currentItem.likeCount} likes"
            Toast.makeText(context, if (currentItem.isLiked) "Liked!" else "Unliked!", Toast.LENGTH_SHORT).show()
        }

        holder.commentIcon.setOnClickListener {
            Toast.makeText(context, "Comment on ${currentItem.userName}'s post", Toast.LENGTH_SHORT).show()
            // TODO: Implement comment functionality (e.g., open dialog/activity)
        }

        holder.shareIcon.setOnClickListener {
            Toast.makeText(context, "Share ${currentItem.userName}'s post", Toast.LENGTH_SHORT).show()
            // TODO: Implement share functionality (e.g., Intent.ACTION_SEND)
        }

        holder.saveIcon.setOnClickListener {
            currentItem.isSaved = !currentItem.isSaved
            updateSaveButton(holder.saveIcon, currentItem.isSaved)
            Toast.makeText(context, if (currentItem.isSaved) "Saved!" else "Unsaved!", Toast.LENGTH_SHORT).show()
        }

    }

    override fun getItemCount(): Int {
        return postList.size
    }

    private fun updateLikeButton(icon: ImageView, isLiked: Boolean) {
        if (isLiked) {
            icon.setImageResource(R.drawable.heart) // Ensure you have this filled heart icon
        } else {
            icon.setImageResource(R.drawable.heart__1_)
        }
    }

    private fun updateSaveButton(icon: ImageView, isSaved: Boolean) {
        if (isSaved) {
            icon.setImageResource(R.drawable.save) // Ensure you have this filled save icon
        } else {
            icon.setImageResource(R.drawable.save)
        }
    }

    fun addPosts(newPosts: List<FeedPostItem>) {
        val startPosition = postList.size
        postList.addAll(newPosts)
        notifyItemRangeInserted(startPosition, newPosts.size)
    }

    fun clearPosts() {
        postList.clear()
        notifyDataSetChanged()
    }
}