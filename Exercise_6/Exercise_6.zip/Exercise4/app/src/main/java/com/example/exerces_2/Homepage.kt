package com.example.exercise_2

// ... (other imports remain the same)
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exerces_2.FeedPostAdapter
import com.example.exerces_2.FeedPostItem
import com.google.android.material.bottomnavigation.BottomNavigationView

class Homepage : AppCompatActivity() {
    // ... (other class variables remain the same)
    private lateinit var bottomNavigationView: BottomNavigationView
    private val PICK_IMAGE_REQUEST_UPLOAD_NAV = 200

    private lateinit var recyclerViewFeed: RecyclerView
    private lateinit var feedAdapter: FeedPostAdapter
    private val feedPostList = mutableListOf<FeedPostItem>()
    private lateinit var fragmentContainer: FrameLayout


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        recyclerViewFeed = findViewById(R.id.recyclerViewFeed)
        fragmentContainer = findViewById(R.id.fragment_container)

        setupRecyclerView()
        loadFiveSampleFeedPosts() // Call the updated function

        bottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    recyclerViewFeed.visibility = View.VISIBLE
                    fragmentContainer.visibility = View.GONE
                    supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
                    true
                }
                R.id.nav_profile -> {
                    recyclerViewFeed.visibility = View.GONE
                    fragmentContainer.visibility = View.VISIBLE
                    loadFragment(ProfileFragment()) // Assuming ProfileFragment exists
                    true
                }
                R.id.nav_upload -> {
                    openImagePickerForUpload()
                    true
                }
                else -> false
            }
        }

        if (savedInstanceState == null) {
            bottomNavigationView.selectedItemId = R.id.nav_home
            recyclerViewFeed.visibility = View.VISIBLE
            fragmentContainer.visibility = View.GONE
        }
    }

    private fun setupRecyclerView() {
        feedAdapter = FeedPostAdapter(this, feedPostList)
        recyclerViewFeed.adapter = feedAdapter
        recyclerViewFeed.layoutManager = LinearLayoutManager(this)
    }

    // Updated function to load exactly 5 posts
    private fun loadFiveSampleFeedPosts() {
        feedAdapter.clearPosts() // Clear any old data

        val posts = mutableListOf<FeedPostItem>()

        // Post 1
        posts.add(
            FeedPostItem(
                postId = "201",
                userProfileImageUrl = "https://randomuser.me/api/portraits/women/10.jpg",
                userName = "Naruto",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor1}", // <--- PASTE HERE FOR THE FIRST IMAGE
                isLiked = false,
                likeCount = 10,
                commentCount = 2,
                viewCountText = "143k views",
                descriptionText = "Ride Safe!",
                isSaved = false
            )
        )

        // Post 2
        posts.add(
            FeedPostItem(
                postId = "202",
                userProfileImageUrl = "https://randomuser.me/api/portraits/men/20.jpg",
                userName = "Sasuke",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor2}", // <--- PASTE HERE FOR THE SECOND IMAGE
                isLiked = true,
                likeCount = 75000,
                commentCount = 8,
                viewCountText = "734k views",
                descriptionText = "Lets Ride!.",
                isSaved = true
            )
        )

        // Post 3
        posts.add(
            FeedPostItem(
                postId = "203",
                userProfileImageUrl = "https://randomuser.me/api/portraits/women/30.jpg",
                userName = "Madara",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor3}", // <--- PASTE HERE FOR THE THIRD IMAGE
                isLiked = false,
                likeCount = 33,
                commentCount = 5,
                viewCountText = "559k views",
                descriptionText = "What a great view.",
                isSaved = false
            )
        )

        // Post 4
        posts.add(
            FeedPostItem(
                postId = "204",
                userProfileImageUrl = "https://randomuser.me/api/portraits/men/40.jpg",
                userName = "Tandang RIder",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor4}", // <--- PASTE HERE FOR THE FOURTH IMAGE
                isLiked = true,
                likeCount = 150,
                commentCount = 15,
                viewCountText = "5k views",
                descriptionText = "Another day!",
                isSaved = true
            )
        )

        // Post 5
        posts.add(
            FeedPostItem(
                postId = "205",
                userProfileImageUrl = "https://randomuser.me/api/portraits/women/50.jpg",
                userName = "Ghost Rider",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor5}", // <--- PASTE HERE FOR THE FIFTH IMAGE
                isLiked = false,
                likeCount = 21,
                commentCount = 3,
                viewCountText = "220k views",
                descriptionText = "Beautiful Sunset!",
                isSaved = false
            )
        )

        // Post 6
        posts.add(
            FeedPostItem(
                postId = "201",
                userProfileImageUrl = "https://randomuser.me/api/portraits/women/60.jpg",
                userName = "Itachi",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor6}", // <--- PASTE HERE FOR THE FIRST IMAGE
                isLiked = false,
                likeCount = 100,
                commentCount = 23,
                viewCountText = "143k views",
                descriptionText = "Rider!",
                isSaved = false
            )
        )

        // Post 7
        posts.add(
            FeedPostItem(
                postId = "202",
                userProfileImageUrl = "https://randomuser.me/api/portraits/men/70.jpg",
                userName = "Boruto",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor7}", // <--- PASTE HERE FOR THE SECOND IMAGE
                isLiked = true,
                likeCount = 75000,
                commentCount = 8,
                viewCountText = "734k views",
                descriptionText = "Lets Ride!.",
                isSaved = true
            )
        )

        // Post 8
        posts.add(
            FeedPostItem(
                postId = "Pain",
                userProfileImageUrl = "https://randomuser.me/api/portraits/women/80.jpg",
                userName = "Madara",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor8}", // <--- PASTE HERE FOR THE THIRD IMAGE
                isLiked = false,
                likeCount = 33,
                commentCount = 5,
                viewCountText = "559k views",
                descriptionText = "What a great view.",
                isSaved = false
            )
        )

        // Post 9
        posts.add(
            FeedPostItem(
                postId = "204",
                userProfileImageUrl = "https://randomuser.me/api/portraits/men/90.jpg",
                userName = "Kisame",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor9}", // <--- PASTE HERE FOR THE FOURTH IMAGE
                isLiked = true,
                likeCount = 150,
                commentCount = 15,
                viewCountText = "5k views",
                descriptionText = "Another day!",
                isSaved = true
            )
        )

        // Post 10
        posts.add(
            FeedPostItem(
                postId = "205",
                userProfileImageUrl = "https://randomuser.me/api/portraits/women/100.jpg",
                userName = "Snorlax",
                postImageUrl = "android.resource://${packageName}/${R.drawable.motor10}", // <--- PASTE HERE FOR THE FIFTH IMAGE
                isLiked = false,
                likeCount = 21,
                commentCount = 3,
                viewCountText = "220k views",
                descriptionText = "Beautiful Sunset!",
                isSaved = false
            )
        )

        feedAdapter.addPosts(posts)
    }

    private fun loadFragment(fragment: Fragment) {
        recyclerViewFeed.visibility = View.GONE
        fragmentContainer.visibility = View.VISIBLE
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun openImagePickerForUpload() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        try {
            startActivityForResult(intent, PICK_IMAGE_REQUEST_UPLOAD_NAV)
        } catch (e: Exception) {
            Log.e("Homepage", "Error starting image picker: ${e.message}")
            Toast.makeText(this, "Could not open image picker", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val imageUri: Uri = data.data!!
            when (requestCode) {
                PICK_IMAGE_REQUEST_UPLOAD_NAV -> {
                    val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
                    if (currentFragment is ProfileFragment) {
                        currentFragment.handleNavigationUploadImage(imageUri)
                    } else {
                        Toast.makeText(this, "Image selected for new post (not implemented): $imageUri", Toast.LENGTH_LONG).show()
                        // You could add the new image as a new post here if you want:
                        // val newPost = FeedPostItem(
                        //     postId = "new_${System.currentTimeMillis()}",
                        //     userProfileImageUrl = "https://randomuser.me/api/portraits/lego/1.jpg", // Default for uploaded by current user
                        //     userName = "You", // Or the actual username
                        //     postImageUrl = imageUri.toString(),
                        //     isLiked = false,
                        //     likeCount = 0,
                        //     commentCount = 0,
                        //     viewCountText = "0 views",
                        //     descriptionText = "My new upload!",
                        //     isSaved = false
                        // )
                        // feedPostList.add(0, newPost) // Add to the top of the list
                        // feedAdapter.notifyItemInserted(0)
                        // recyclerViewFeed.scrollToPosition(0)
                        // // Ensure the feed is visible and selected
                        // recyclerViewFeed.visibility = View.VISIBLE
                        // fragmentContainer.visibility = View.GONE
                        // bottomNavigationView.selectedItemId = R.id.nav_home
                    }
                }
            }
        }
    }
}