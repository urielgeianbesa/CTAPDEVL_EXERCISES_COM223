package com.example.exerces_2

data class FeedPostItem(
    val postId: String, // Unique ID for the post
    val userProfileImageUrl: String?, // URL or resource ID for the user's profile pic
    val userName: String,
    val postImageUrl: String, // URL or resource ID for the main post image
    var isLiked: Boolean = false,
    var likeCount: Int = 0, // You might want to display this
    var commentCount: Int = 0,
    val viewCountText: String, // e.g., "17,280 views"
    val descriptionText: String, // e.g., "instagram template"
    var isSaved: Boolean = false // For the save icon
)