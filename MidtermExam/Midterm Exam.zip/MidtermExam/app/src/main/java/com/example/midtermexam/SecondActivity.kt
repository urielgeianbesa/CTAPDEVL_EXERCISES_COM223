package com.example.midtermexam
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.midtermexam.R

private const val ActivityDestroy = "SecondActivity"

class SecondActivity : AppCompatActivity() {

    private lateinit var receivedTextView: TextView
    private lateinit var goToThirdActivityButton: Button
    private var receivedText: String? = null
    private val TAG=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        receivedTextView = findViewById(R.id.receivedTextView)
        goToThirdActivityButton = findViewById(R.id.goToThirdActivityButton)

        receivedText = intent.getStringExtra("inputText")
        receivedTextView.text = receivedText ?: "" // Use "" if null


        goToThirdActivityButton.setOnClickListener {
            val intent = Intent(this, ThirdActivity::class.java)
            intent.putExtra("inputText", receivedText)
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "activity 2 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "activity 2 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "activity 2 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "activity 2 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "activity 2 has destroyed")
    }
}