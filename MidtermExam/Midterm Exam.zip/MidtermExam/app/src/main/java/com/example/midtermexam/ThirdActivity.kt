package com.example.midtermexam
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.midtermexam.R

private const val ActivityDestroy = "ThirdActivity"

class ThirdActivity : AppCompatActivity() {

    private lateinit var receivedTextView: TextView
    private lateinit var goToGitHubButton: Button
    private val TAG=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        receivedTextView = findViewById(R.id.receivedTextView)
        goToGitHubButton = findViewById(R.id.goToGitHubButton)

        val receivedText = intent.getStringExtra("inputText")
        receivedTextView.text = receivedText ?: "" // Use "" if null

        Log.d(ActivityDestroy, "activity 3 has created")

        goToGitHubButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/yourusername")) // Replace with your GitHub username
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "activity 3 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "activity 3 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "activity 3 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "activity 3 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "activity 3 has destroyed")
    }
}