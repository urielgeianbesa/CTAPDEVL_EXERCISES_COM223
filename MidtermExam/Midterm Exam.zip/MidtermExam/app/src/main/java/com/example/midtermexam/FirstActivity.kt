package com.example.midtermexam
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.midtermexam.R

private const val ActivityDestroy = "FirstActivity"

class FirstActivity : AppCompatActivity() {

    private lateinit var plainTextInput: EditText
    private lateinit var goToSecondActivityButton: Button
    private val TAG=""
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)

        plainTextInput = findViewById(R.id.plainTextInput)
        goToSecondActivityButton = findViewById(R.id.goToSecondActivityButton)



        goToSecondActivityButton.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            val text = plainTextInput.text.toString()
            intent.putExtra("inputText", text)
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "activity 1 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "activity 1 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "activity 1 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "activity 1 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "activity 1 has destroyed")
    }
}