package com.example.exercise_2

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment() {

    private lateinit var profilePicImageView: ImageView
    private lateinit var editProfileButton: Button
    private lateinit var shareProfileButton: Button
    private lateinit var nameProfilePageTextView: TextView
    private lateinit var imageProfile1: ImageView
    private lateinit var imageProfile2: ImageView
    private lateinit var imageProfile3: ImageView

    private val PICK_IMAGE_REQUEST_PROFILE = 123
    private val PICK_IMAGE_REQUEST_1 = 125
    private val PICK_IMAGE_REQUEST_2 = 126
    private val PICK_IMAGE_REQUEST_3 = 127

    private var selectedProfileImageUri: Uri? = null
    private val selectedImageUris = arrayOfNulls<Uri>(3)
    private var username: String? = null
    private var nextImageIndexToUpdate = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.activity_profilepage, container, false)

        profilePicImageView = view.findViewById(R.id.profilePicImageView) // Corrected ID
        editProfileButton = view.findViewById(R.id.editProfileButton)
        shareProfileButton = view.findViewById(R.id.shareProfileButton)
        nameProfilePageTextView = view.findViewById(R.id.nameProfilePageTextView)
        imageProfile1 = view.findViewById(R.id.imageProfile1)
        imageProfile2 = view.findViewById(R.id.imageProfile2)
        imageProfile3 = view.findViewById(R.id.imageProfile3)

        username = arguments?.getString("USER_NAME")
        nameProfilePageTextView.text = username ?: "User Name"

        profilePicImageView.setOnClickListener {
            openImagePicker(PICK_IMAGE_REQUEST_PROFILE)
        }

        editProfileButton.setOnClickListener {
            openImagePicker(nextRequestCode())
        }

        shareProfileButton.setOnClickListener {
            shareProfile()
        }

        imageProfile1.setOnClickListener {
            openImagePicker(PICK_IMAGE_REQUEST_1)
        }

        imageProfile2.setOnClickListener {
            openImagePicker(PICK_IMAGE_REQUEST_2)
        }

        imageProfile3.setOnClickListener {
            openImagePicker(PICK_IMAGE_REQUEST_3)
        }

        return view
    }

    private fun nextRequestCode(): Int {
        return when (nextImageIndexToUpdate) {
            0 -> PICK_IMAGE_REQUEST_1
            1 -> PICK_IMAGE_REQUEST_2
            2 -> PICK_IMAGE_REQUEST_3
            else -> PICK_IMAGE_REQUEST_1 // Default, shouldn't happen
        }
    }

    private fun openImagePicker(requestCode: Int) {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        try {
            startActivityForResult(intent, requestCode)
        } catch (e: Exception) {
            Log.e("ProfilePage", "Error starting image picker: ${e.message}")
            Toast.makeText(requireContext(), "Could not open image picker", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val imageUri: Uri = data.data!!
            Log.i("ProfilePage", "onActivityResult: Received image URI: $imageUri for code $requestCode")
            when (requestCode) {
                PICK_IMAGE_REQUEST_PROFILE -> {
                    selectedProfileImageUri = imageUri
                    profilePicImageView.setImageURI(imageUri)
                }
                PICK_IMAGE_REQUEST_1, PICK_IMAGE_REQUEST_2, PICK_IMAGE_REQUEST_3 -> {
                    updateProfileImages(requestCode, imageUri)
                }
                else -> Log.w("ProfilePage", "onActivityResult: Unknown request code: $requestCode")
            }
        } else if (resultCode == Activity.RESULT_OK) {
            Toast.makeText(requireContext(), "No image selected", Toast.LENGTH_SHORT).show()
        } else {
            Log.i("ProfilePage", "Activity result cancelled or failed")
        }
    }

    private fun updateProfileImages(requestCode: Int, uri: Uri) {
        when (requestCode) {
            PICK_IMAGE_REQUEST_1 -> {
                selectedImageUris[0] = uri
                imageProfile1.setImageURI(uri)
                if (nextImageIndexToUpdate == 0) nextImageIndexToUpdate = 1
            }
            PICK_IMAGE_REQUEST_2 -> {
                selectedImageUris[1] = uri
                imageProfile2.setImageURI(uri)
                if (nextImageIndexToUpdate == 1) nextImageIndexToUpdate = 2
            }
            PICK_IMAGE_REQUEST_3 -> {
                selectedImageUris[2] = uri
                imageProfile3.setImageURI(uri)
                if (nextImageIndexToUpdate == 2) nextImageIndexToUpdate = 0
            }
        }
    }

    private fun shareProfile() {
        val intent = Intent(requireContext(), Homepage::class.java)
        intent.putExtra("profile_image_uri", selectedProfileImageUri?.toString())
        intent.putExtra("USER_NAME", username)
        startActivity(intent)
    }

    // New function to handle image upload from navigation
    fun handleNavigationUploadImage(uri: Uri) {
        Log.d("ProfileFragment", "handleNavigationUploadImage: $uri")
        if (nextImageIndexToUpdate in 0..2) {
            selectedImageUris[nextImageIndexToUpdate] = uri
            updateImageView(nextImageIndexToUpdate, uri)
            nextImageIndexToUpdate++
            if (nextImageIndexToUpdate > 2) {
                nextImageIndexToUpdate = 0
            }
        } else {
            Log.e(
                "ProfileFragment",
                "handleNavigationUploadImage: Invalid nextImageIndexToUpdate: $nextImageIndexToUpdate"
            )
        }
    }

    private fun updateImageView(index: Int, uri: Uri) {
        when (index) {
            0 -> imageProfile1.setImageURI(uri)
            1 -> imageProfile2.setImageURI(uri)
            2 -> imageProfile3.setImageURI(uri)
        }
    }
}