package com.example.exercise_2

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class Homepage : AppCompatActivity() {
    private var username: String? = null
    private lateinit var bottomNavigationView: BottomNavigationView
    private val PICK_IMAGE_REQUEST_UPLOAD_NAV = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        username = intent.getStringExtra("USER_NAME")
        val userNameTextView: TextView = findViewById(R.id.User_name)
        userNameTextView.text = username ?: "Guest"

        bottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Pop the back stack to show the base layout
                    supportFragmentManager.popBackStack()
                    true
                }
                R.id.nav_profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                R.id.nav_upload -> {
                    openImagePickerForUpload()
                    true
                }
                else -> false
            }
        }

        // Load an initial fragment or perform initial setup if needed.
        if (savedInstanceState == null) {
            bottomNavigationView.selectedItemId = R.id.nav_home
            // If you have initial content within the fragment_container, load it here
            // loadFragment(InitialFragment())
        }

        // Get the image URI from the Intent and display it (if any)
        val imageUriString = intent.getStringExtra("profile_image_uri")
        imageUriString?.let {
            val imageUri = Uri.parse(it)
            findViewById<ImageView>(R.id.porfile1)?.setImageURI(imageUri)
            findViewById<ImageView>(R.id.imageView8)?.setImageURI(imageUri)
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null) // VERY IMPORTANT: Add to back stack
            .commit()
    }

    private fun openImagePickerForUpload() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        try {
            startActivityForResult(intent, PICK_IMAGE_REQUEST_UPLOAD_NAV)
        } catch (e: Exception) {
            Log.e("Homepage", "Error starting image picker: ${e.message}")
            Toast.makeText(this, "Could not open image picker", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val imageUri: Uri = data.data!!
            when (requestCode) {
                PICK_IMAGE_REQUEST_UPLOAD_NAV -> {
                    val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
                    if (currentFragment is ProfileFragment) {
                        currentFragment.handleNavigationUploadImage(imageUri)
                    } else {
                        Log.w("Homepage", "onActivityResult: Upload image - ProfileFragment not visible")
                        Toast.makeText(this, "Cannot upload image now", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}